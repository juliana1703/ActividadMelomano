class Config:
    SECRET_KEY = 'CLAVE'
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'melomano_db22'
    SESSION_COOKIE_SECURE: False