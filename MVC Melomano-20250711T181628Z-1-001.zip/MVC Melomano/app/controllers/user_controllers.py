from flask import Blueprint, render_template, request, redirect, url_for, current_app
from flask_bcrypt import Bcrypt
from flask import session
from app import bcrypt
user_bp = Blueprint('user_bp', __name__)


@user_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        print("Email recibido:", email)
        print("Contraseña ingresada:", password)

        connection = current_app.connection
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT * FROM usuarios WHERE email=%s", (email,))
                result = cursor.fetchone()
                
                print("Resultado de consulta:", result)

                if result:
                    print("Hash guardado:", result['password'])
                    print("¿Coincide?", bcrypt.check_password_hash(result['password'], password))

                if result and bcrypt.check_password_hash(result['password'], password):
                    session['user_email'] = email
                    return redirect(url_for('user_bp.profile'))
                else:
                    return "Correo o contraseña incorrecta"
        except Exception as e:
            return str(e)

    return render_template('iniciosesion.html')



@user_bp.route('/registre', methods=['GET','POST'])
def registre():
    connection = current_app.connection
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        email = request.form['email']
        password = request.form['password']
        id_rol = request.form['rol']
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
       
        try:
          with connection.cursor() as cursor:
                cursor.execute("INSERT INTO usuarios (nombre, apellido, email, password, id_rol, profile_picture ) VALUES (%s, %s, %s, %s, %s, %s)", (nombre,apellido, email, hashed_password, id_rol, None))
                connection.commit()
          return redirect(url_for('user_bp.login'))
        except Exception as e:
            return str(e)

    try:
         with connection.cursor() as cursor:
                cursor.execute("SELECT id_rol, nombre FROM roles")
                roles = cursor.fetchall()
    except Exception as e:
           return str(e)
    
    return render_template('prueba.html', roles=roles)
      

@user_bp.route('/profile')
def profile():
    print("Sesión iniciada:", session.get('user_email'))
    email = session.get('user_email')
    print("Sesión en /profile:", email)
    if not email:
        return redirect(url_for('user_bp.login'))
    
    connection = current_app.connection 
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT nombre, apellido, email, id_rol FROM usuarios WHERE email=%s", (email,))
            user = cursor.fetchone()
            if not user:
                return "Usuario no encontrado"
    except Exception as e:
        return f"Error al cargar el perfil: {str(e)}"
    
    return render_template('perfil.html', user=user)

        

#Ruta para que el administrador ingrese un usuario

@user_bp.route('/admi/crear_melomano', methods=['GET','POST'])
def agregarmelomano():
    connection = current_app.connection

    if request.method == 'POST':
       
           nombre = request.form['nombre']
           Apellido = request.form['apellido']
           email = request.form['email']
           password = request.form['password']
           hashed_pasword = bcrypt.generate_password_hash(password).decode('utf-8')

           id_rol = 2

           try:
              with connection.cursor()as cusor:
                  cusor.execute("""
                   INSERT INTO usuarios(nombre, Apellido, email, password, id_rol, profile_picture) VALUES (%s,%s,%s,%s,%s,%s)
                 """, (nombre, Apellido, email, password, id_rol, None))
                  connection.commit()
                  return redirect(url_for('user_bp.listamelomanos'))
           except Exception as e:
               return str(e)
           
    return render_template('formulariosusuarios.html')




                             
@user_bp.route('/admin/melomanos')
def mostrar_melomanos():
    connection = current_app.connection
    try:
        with connection.cursor() as cursor:
            cursor.execute("""
                SELECT id_usuarios, nombre, apellido, email FROM usuarios
                WHERE id_rol = 2
            """)
            melomanos = cursor.fetchall()
    except Exception as e:
        return str(e)

    return render_template('formulariosusuarios.html', usuarios=melomanos)


